package com.flipkart.test;

import org.openqa.selenium.WebDriver;
import org.testng.annotations.AfterTest;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.BeforeSuite;
import org.testng.annotations.BeforeTest;
import org.testng.annotations.Test;

import com.flipkart.init.GetterSetterMethods;
import com.flipkart.init.LaunchBrowser;
import com.flipkart.pageobject.Login;
import com.flipkart.pageobject.Logout;
import com.flipkart.pageobject.PlaceOrder;

public class FlipKartTest extends GetterSetterMethods {

	Login login;
	Logout logout;
	LaunchBrowser launchBrowser;
	PlaceOrder placeOrder;
	public WebDriver driver;

	public FlipKartTest() throws Exception {
		login = new Login();
		logout = new Logout();
		launchBrowser = new LaunchBrowser();
		placeOrder = new PlaceOrder();

	}

	/**
	 * This method is to purchase a product through flipkart application. Creator
	 * athira.sasidharan<08/20/2019>
	 */
	@Test
	public void flipkartOrderSubmission() throws Exception {

		System.out.println("Starting with FlipKart Test Scenarios");
		// Selecting product
		placeOrder.selectProduct();
		// Verify and Purchase product
		placeOrder.verifyAndPurchaseProduct();

	}

	/**
	 * This method is to read input values from text file. Creator
	 * athira.sasidharan<08/20/2019>
	 */
	@BeforeSuite
	public void readValues() throws Exception {
		launchBrowser.readValuesFromFile();
	}

	/**
	 * This method is to launch browser according to user input. Creator
	 * athira.sasidharan<08/20/2019>
	 */
	@BeforeTest
	public void launchBrowser() throws Exception {
		launchBrowser.doLaunchBrowser();

	}

	/**
	 * This method is to login to the filpkart application. Creator
	 * athira.sasidharan<08/20/2019>
	 */
	@BeforeClass
	public void loginTest() throws Exception {
		login.doLogin();

	}

	/**
	 * This method is to logout from flipkart application. Creator
	 * athira.sasidharan<08/20/2019>
	 */
	@AfterTest
	public void logoutTest() throws Exception {
		logout.doLogout();

	}

}
