package com.flipkart.constants;

public class ReportingConstants {

	public String PASS = "Pass";
	public String FAIL = "Fail";

	public boolean TRUE = true;
	public boolean FALSE = false;

}
