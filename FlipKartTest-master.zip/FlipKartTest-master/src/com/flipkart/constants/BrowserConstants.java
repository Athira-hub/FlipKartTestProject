package com.flipkart.constants;

public class BrowserConstants {
	// We can use the below constants if values are not entered from external source
	public String CHROME = "chrome";
	public String FIREFOX = "firefox";
	public String IE = "ie";
}
