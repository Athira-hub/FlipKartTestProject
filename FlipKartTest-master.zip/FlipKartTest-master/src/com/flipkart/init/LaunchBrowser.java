package com.flipkart.init;

import java.io.BufferedReader;
import java.io.FileReader;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.firefox.FirefoxDriver;

import com.flipkart.constants.BrowserConstants;
import com.flipkart.constants.FlipKartConstants;
import com.flipkart.constants.ReportingConstants;

import junit.framework.Assert;

public class LaunchBrowser extends GetterSetterMethods {
	BrowserConstants browserConstants;
	ReportingConstants reportingConstants;
	FlipKartConstants flipkartConstants;
	public WebDriver driver;

	public LaunchBrowser() {
		browserConstants = new BrowserConstants();
		reportingConstants = new ReportingConstants();
		flipkartConstants = new FlipKartConstants();
	}

	// This method is to fetch input values from text file
	public void readValuesFromFile() throws Exception {
		FileReader FR = new FileReader(flipkartConstants.TestFile);
		BufferedReader BR = new BufferedReader(FR);
		String username = BR.readLine();
		String password = BR.readLine();
		String itemName = BR.readLine();
		String browser = BR.readLine();
		setUserName(username);
		setPassword(password);
		setItemName(itemName);
		setBrowser(browser);
	}

	/**
	 * This method is to Launch browser according to the user input Creator
	 * athira.sasidharan<08/20/2019>
	 **/

	public void doLaunchBrowser() {

		try {

			if (getBrowser().equalsIgnoreCase(browserConstants.CHROME)) {
				// Initialize chrome browser
				System.setProperty("webdriver.chrome.driver", "C:\\chromedriver.exe");
				driver = new ChromeDriver();
				Assert.assertTrue(reportingConstants.TRUE);
				System.out.println(reportingConstants.PASS);
			} else if (getBrowser().equalsIgnoreCase(browserConstants.FIREFOX)) {
				// Initialize firefox browser
				System.setProperty("webdriver.firefox.marionette", "C:\\geckodriver.exe");
				driver = new FirefoxDriver();
				Assert.assertTrue(reportingConstants.TRUE);
				System.out.println(reportingConstants.PASS);
			} else if (getBrowser().equalsIgnoreCase(browserConstants.IE)) {
				// Initialize IE browser
				System.setProperty("webdriver.ie.driver", "C:\\IEDriverServer.exe");
				driver = new FirefoxDriver();
				Assert.assertTrue(reportingConstants.TRUE);
				System.out.println(reportingConstants.PASS);
			} else {
				System.out.println("No Browser is selected");
				Assert.assertFalse(true);
				System.out.println(reportingConstants.FAIL);
			}
			// Launch the browser and direct it to the Base URL
			driver.get(flipkartConstants.baseUrl);
			String url = driver.getCurrentUrl();
			// Maximize the screen
			driver.manage().window().maximize();
			// Validate the base url and the url which is launched are same
			Assert.assertEquals(flipkartConstants.baseUrl, url);
			setDriver(driver);

		} catch (Exception e) {
			throw new IllegalArgumentException();
		}

	}

}
