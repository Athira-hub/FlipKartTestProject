package com.flipkart.init;

import org.openqa.selenium.WebDriver;

public class GetterSetterMethods {
	public static WebDriver driver;
	public static String itemName;
	public static String UserNameInput;
	public static String password;

	public String getBrowser() {
		return browser;
	}

	public void setBrowser(String browser) {
		this.browser = browser;
	}

	public String browser;

	public String getUserName() {
		return UserNameInput;
	}

	public void setUserName(String userName) {
		UserNameInput = userName;
	}

	public String getPassword() {
		return password;
	}

	public void setPassword(String password) {
		this.password = password;
	}

	public String getItemName() {
		return itemName;
	}

	public void setItemName(String itemName) {
		this.itemName = itemName;
	}

	public WebDriver getDriver() {
		return driver;
	}

	public void setDriver(WebDriver driver) {
		this.driver = driver;
	}
}
