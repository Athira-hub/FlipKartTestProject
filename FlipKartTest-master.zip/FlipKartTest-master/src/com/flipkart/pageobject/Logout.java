package com.flipkart.pageobject;

import java.io.IOException;

import org.junit.Assert;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.interactions.Actions;

import com.flipkart.constants.ReportingConstants;
import com.flipkart.init.GetterSetterMethods;
import com.flipkart.objrepo.FLIPKARTOBJ;

public class Logout extends GetterSetterMethods {

	ReportingConstants reportingConstants;
	private FLIPKARTOBJ flipkartObj;

	public Logout() throws IOException {
		reportingConstants = new ReportingConstants();
		flipkartObj = new FLIPKARTOBJ("FlipkartObjRepo.properties");
	}

	/**
	 * This method is to logout from the flipkart application Creator
	 * athira.sasidharan<08/20/2019>
	 **/

	public void doLogout() throws Exception {
		WebDriver driver = GetterSetterMethods.driver;
		// Navigate to FlipKart Home page
		driver.findElement(flipkartObj.getbjectLocator("FlipkartHome")).click();
		Actions actions = new Actions(driver);
		WebElement myAcctName = driver.findElement(flipkartObj.getbjectLocator("MyAccount"));
		actions.moveToElement(myAcctName).perform();
		// Click on Logout
		driver.findElement(flipkartObj.getbjectLocator("LogOutLink")).click();
		Thread.sleep(2000);

		System.out.println("Logout is successful");
		Assert.assertTrue(reportingConstants.TRUE);
		driver.close();
		driver.quit();

	}
}
