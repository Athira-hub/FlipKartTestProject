package com.flipkart.pageobject;

import java.io.IOException;
import java.util.ArrayList;

import org.junit.Assert;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.Keys;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;

import com.flipkart.constants.ReportingConstants;
import com.flipkart.init.GetterSetterMethods;
import com.flipkart.init.LaunchBrowser;
import com.flipkart.objrepo.FLIPKARTOBJ;

public class PlaceOrder extends GetterSetterMethods {

	ReportingConstants reportingConstants;
	private FLIPKARTOBJ flipkartObj;
	LaunchBrowser launchBrowser;

	public PlaceOrder() throws IOException {
		reportingConstants = new ReportingConstants();
		flipkartObj = new FLIPKARTOBJ("FlipkartObjRepo.properties");
		launchBrowser = new LaunchBrowser();
	}

	/**
	 * This method is to select a product after login Creator
	 * athira.sasidharan<08/20/2019>
	 **/
	public void selectProduct() throws Exception {

		WebDriver driver = GetterSetterMethods.driver;
		String itemName = GetterSetterMethods.itemName;

		// Search for an item in the search textbox
		driver.findElement(flipkartObj.getbjectLocator("InputItem")).sendKeys(itemName);
		driver.findElement(flipkartObj.getbjectLocator("InputItem")).sendKeys(Keys.ENTER);
		Thread.sleep(1000);
		// Select the required item from the list displayed
		WebElement element = driver.findElement(flipkartObj.getbjectLocator("SelectedItem"));
		((JavascriptExecutor) driver).executeScript("arguments[0].scrollIntoView(true);", element);
		// Navigate to the search result page
		driver.findElement(flipkartObj.getbjectLocator("ItemLink")).click();
		ArrayList<String> tabs2 = new ArrayList<String>(driver.getWindowHandles());
		driver.switchTo().window(tabs2.get(1));

		System.out.println("Product selected..." + reportingConstants.PASS);
		Assert.assertTrue(reportingConstants.TRUE);
	}

	/**
	 * This method is to Get information such as Name,Price and Description about
	 * the item from Search Page,Compare with checkout page and Purchase Creator
	 * athira.sasidharan<08/20/2019>
	 **/
	public void verifyAndPurchaseProduct() throws Exception {

		WebDriver driver = GetterSetterMethods.driver;
		// Get information such as Name,Price and Description about the item from Search
		// Page
		WebElement itemNameDescFromSearch = driver
				.findElement(flipkartObj.getbjectLocator("ItemNameDescFromSearchPage"));
		Thread.sleep(1000);
		String itemNameFromSearchPage = itemNameDescFromSearch.getText();
		WebElement itemPriceFromSearch = driver.findElement(flipkartObj.getbjectLocator("ItemPriceFromSearch"));
		String itemPriceFromSearchPage = itemPriceFromSearch.getText();
		// Scroll and Click on Add to Cart button
		WebElement addToCart = driver.findElement(flipkartObj.getbjectLocator("AddToCartBtn"));
		((JavascriptExecutor) driver).executeScript("arguments[0].scrollIntoView(true);", addToCart);
		Thread.sleep(500);
		addToCart.click();

		// Get information such as Name,Price and Description about the item from
		// Checkout Page
		WebElement itemNameFromCheckout = driver.findElement(flipkartObj.getbjectLocator("ItemNameFromCheckout"));
		String itemNameFromCheckoutPage = itemNameFromCheckout.getText();
		WebElement itemPriceFromCheckout = driver.findElement(flipkartObj.getbjectLocator("ItemPriceFromCheckout"));
		String itemPriceFromCheckoutPage = itemPriceFromCheckout.getText();
		WebElement itemDescFromCheckout = driver.findElement(flipkartObj.getbjectLocator("ItemDescFromCheckout"));
		String itemDescFromCheckoutPage = itemDescFromCheckout.getText();

		// Compare and verify the information of Search and Checkout page are same
		Assert.assertTrue(itemNameFromSearchPage.contains(itemNameFromCheckoutPage));
		Assert.assertTrue(itemNameFromSearchPage.contains(itemDescFromCheckoutPage));
		Assert.assertTrue(itemPriceFromSearchPage.contains(itemPriceFromCheckoutPage));

		// Place Order
		driver.findElement(flipkartObj.getbjectLocator("PlaceOrderBtn")).click();
		Thread.sleep(5000);
	}

}
