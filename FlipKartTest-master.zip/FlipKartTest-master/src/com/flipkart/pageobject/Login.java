package com.flipkart.pageobject;

import org.junit.Assert;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;

import com.flipkart.constants.ReportingConstants;
import com.flipkart.init.GetterSetterMethods;
import com.flipkart.objrepo.FLIPKARTOBJ;

public class Login extends GetterSetterMethods {

	ReportingConstants reportingConstants;
	private FLIPKARTOBJ flipkartObj;

	public Login() throws Exception {
		reportingConstants = new ReportingConstants();
		flipkartObj = new FLIPKARTOBJ("FlipkartObjRepo.properties");

	}

	/**
	 * This method is to Login to the flipkart application
	 * Creator<athira.sasidharan> on<08/20/2019>
	 **/

	public void doLogin() {

		WebDriver driver = GetterSetterMethods.driver;
		String UserNameInput = GetterSetterMethods.UserNameInput;
		String password = GetterSetterMethods.password;
		// Input Username & Password in the login page
		driver.findElement(flipkartObj.getbjectLocator("UserName")).sendKeys(UserNameInput);
		driver.findElement(flipkartObj.getbjectLocator("Password")).sendKeys(password);
		WebElement loginbtn = driver.findElement(flipkartObj.getbjectLocator("LoginBtn"));
		// Click on Login button
		if (loginbtn != null) {
			loginbtn.click();

			System.out.println("Login success..");
			System.out.println("Current User is" + UserNameInput);
			Assert.assertTrue(reportingConstants.TRUE);
		}

	}
}
